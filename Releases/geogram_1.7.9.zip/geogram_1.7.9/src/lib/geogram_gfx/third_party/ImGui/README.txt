imgui: Bloat-free Immediate Mode Graphical User interface for C++ with minimal dependencies
website: https://github.com/ocornut/imgui

This version (1.79 docking branch) pulled Mon 31 Aug 2020 
My patches/changes indicated by [Bruno Levy] tags
Added Android support.
