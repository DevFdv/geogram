ImGui Text Editor
By BalazsJako
This version downloaded from: https://github.com/BalazsJako/ImGuiColorTextEdit
Date: Fri Aug 17 14:49:25 CEST 2018
License: MIT
My modifications are indicated by [Bruno Levy] tags.
