LM6: the Gamma Mesh Format library.

website: https://github.com/LoicMarechal/libMeshb

License: GNU Lesser General Public License
