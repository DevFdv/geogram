This files generated using the program binary_to_compressed_c.cpp 
in ImGui/misc/fonts from the following fonts:

* cousine_regular
   by Steve Matteson
   Digitized data copyright (c) 2010 Google Corporation.
   Licensed under the SIL Open Font License, Version 1.1
   https://fonts.google.com/specimen/Cousine 

* roboto_medium
   Apache License 2.0
   by Christian Robertson
   https://fonts.google.com/specimen/Roboto

* fa_brands
* fa_regular
* fa_solid
   https://fontawesome.com/

