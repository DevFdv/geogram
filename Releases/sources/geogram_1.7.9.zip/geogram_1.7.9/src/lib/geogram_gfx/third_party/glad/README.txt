Glad : Multi-Language GL/GLES/EGL/GLX/WGL Loader-Generator based on the official specs.
Website: http://glad.dav1d.de/

