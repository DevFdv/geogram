rply: ANSI C Library for PLY file format input and output 
website: http://w3.impa.br/~diego/software/rply/
