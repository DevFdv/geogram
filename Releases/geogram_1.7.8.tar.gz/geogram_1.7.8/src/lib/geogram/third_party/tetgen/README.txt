tetgen: A Quality Tetrahedral Mesh Generator and a 3D Delaunay Triangulator
website: http://wias-berlin.de/software/tetgen/

license: GNU Affero General Public License:
http://www.gnu.org/licenses/agpl-3.0.en.html

Free for academic use, contact copyright owners at 
tetgen@wias-berlin.de for other uses, more information on:

http://wias-berlin.de/software/tetgen/1.5/FAQ-license.html