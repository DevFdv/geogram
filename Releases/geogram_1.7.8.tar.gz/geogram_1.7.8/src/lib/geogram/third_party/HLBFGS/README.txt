HLBFGS: a hybrid L-BFGS optimization framework.

Website: http://research.microsoft.com/en-us/um/people/yangliu/software/HLBFGS/

License (quoted from the website): 
HLBFGS is freely available for non-commercial purposes. The
third-party software ICFS is integrated into HLBFGS to modify the
true Hessian if the Hessian is available. The line-search routine
is from the original L-BFGS code and TNPACK.


